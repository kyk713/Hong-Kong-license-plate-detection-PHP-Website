
import urllib.request

urllib.request.urlretrieve("http://www.python.org/images/success/nasa.jpg",
"NASA.jpg")

print("download successful")
print('Hello, world!')
