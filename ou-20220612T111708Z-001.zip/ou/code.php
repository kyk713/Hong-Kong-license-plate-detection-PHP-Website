
<?php
session_start();
include('dbcon.php');
 



if (isset($_POST['save_contact'])) {
    $first1 =  $_POST['first'];
    $sec1 =  $_POST['sec'];
    $profile =  $_FILES['profile']['tmp_name'];
    $random_no = rand(1111, 9999);

    $string = 'Example String\n'; 
$pyout = exec('python test.py');
echo $pyout;


    $new_image = $random_no . $profile;
    $postData = [
        'fname' => $first1,
        'lname' => $sec1,
        'image' => $profile,

    ];
    $ref_table = 'image';
    $postRef_result = $database->getReference($ref_table)->push($postData);

    if ($postRef_result) {
        $_SESSION['status'] = "succ";
        header('Location: index.php');
    } else {
        $_SESSION['status'] = "ggg";
        header('Location: index.php');
    }
}

?>