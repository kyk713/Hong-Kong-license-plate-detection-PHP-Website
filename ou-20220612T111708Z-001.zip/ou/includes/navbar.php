
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link"  href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link"  href="#">login</a>
        </li>

        

    </div>
  </div>
</nav>
<script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>

    <script>
        // Your web app's Firebase configuration
        var firebaseConfig = {
            apiKey: "AIzaSyBWCim420MOwtvN2ymZXQfBS-hXbNXpf6M",
            authDomain: "oufyp-8f2a7.firebaseapp.com",
            databaseURL: "https://oufyp-8f2a7-default-rtdb.firebaseio.com",
            projectId: "oufyp-8f2a7",
            storageBucket: "oufyp-8f2a7.appspot.com",
            messagingSenderId: "1323825919",
            appId: "1:1323825919:web:3030ed0314b5df3dfb2aca",
            measurementId: "G-EMQEFT0XMM"
        };
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
    </script>
