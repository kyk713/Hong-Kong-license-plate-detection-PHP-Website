<?php
include('includes/header.php');
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>add
                        <a href="index.php" class="btn btn-danger float-end">BACK</a>
                    </h4>
                </div>
                <div class="card-body">

                    <form action="code.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group mb-3">
                            <label for="">first</label>
                            <input type="text" name="first" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">sec</label>
                            <input type="text" name="sec" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                        <label for="img">Select image:</label>
  <input type="file"  name="profile" class="form-control" accept="image/*">
                        </div>


                        <div class="form-group mb-3">
                        <label>select image : </label>
            <input type="file" id="image" accept="image/*" multiple><br><br>
            <button type="button" onclick="upload()" multiple>Upload</button>
                        </div>

                        <input type="button" id='script' name="scriptbutton" value=" Run Script " onclick="goPython()">

                        <div class="form-group mb-3">
                            <button type="submit" name="save_contact" class="btn btn-primary">SAVE</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
   var res = "Good Luck!!!!";
   $.ajax({
  type: "POST",
  url: "~/test.py"
//   data: { param: text}
}).done(function( o ) {
   // do something
});
</script>
<?php
//    echo "<script>document.writeln(res);</script>";
?>
</div>
<script type="text/javascript" src="js/upload1.js"></script>
<?php
include('includes/footer.php');
?>