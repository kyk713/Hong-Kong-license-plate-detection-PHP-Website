<html>

<head>
    <title>upload image to firebase</title>
</head>

<body>
    <center>
        <form enctype="multipart/form-data">
            <label>select image : </label>
            <input type="file" id="image" accept="image/*"><br><br>
            <button type="button" onclick="upload()">Upload</button>
        </form>
    </center>






    <!-- The core Firebase JS SDK is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>

    <!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#config-web-app -->

    <script>
        // Your web app's Firebase configuration
        var firebaseConfig = {
            apiKey: "AIzaSyBWCim420MOwtvN2ymZXQfBS-hXbNXpf6M",
            authDomain: "oufyp-8f2a7.firebaseapp.com",
            databaseURL: "https://oufyp-8f2a7-default-rtdb.firebaseio.com",
            projectId: "oufyp-8f2a7",
            storageBucket: "oufyp-8f2a7.appspot.com",
            messagingSenderId: "1323825919",
            appId: "1:1323825919:web:3030ed0314b5df3dfb2aca",
            measurementId: "G-EMQEFT0XMM"
        };
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
    </script>
    <script type="text/javascript" src="js/uploadimage.js"></script>
</body>

</html>