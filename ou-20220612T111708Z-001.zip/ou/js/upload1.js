


window.yourGlobalVariable;
function upload() {

    //get your select image
    var image = document.getElementById("image").files[0];
    //now get your image name
    var imageName = image.name;
    //firebase  storage reference
    //it is the path where yyour image will store
    var storageRef = firebase.storage().ref('images/' + imageName);
    //upload image to selected storage reference

    var uploadTask = storageRef.put(image);

    uploadTask.on('state_changed', function (snapshot) {
        //observe state change events such as progress , pause ,resume
        //get task progress by including the number of bytes uploaded and total
        //number of bytes
        var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log("upload is " + progress + " done");
    }, function (error) {
        //handle error here
        console.log(error.message);
    }, function () {
        //handle successful uploads on complete

        uploadTask.snapshot.ref.getDownloadURL().then(function (downlaodURL) {
            //get your upload image url here...
            yourGlobalVariable = downlaodURL;
            console.log(downlaodURL);
            console.log(yourGlobalVariable);
            insert();


        });
    });



}
function insert() {
    console.log(yourGlobalVariable);
    var resultImage = "";
    var resultOCR = "";


    let r = Math.random().toString(36).substring(7);
    console.log("random", r);

    //pre built function to upload data to firebase
    //path where your data will be stored
    firebase.database().ref('image/' + r).set({
        image: yourGlobalVariable,
        result: resultImage,
        ocr: resultOCR


    });
    goPython();

    $.ajax({
        type: "POST",
        data: {"downloadURL":yourGlobalVariable} ,
        success: function(data)
        {
            //alert(data);
        }
    });   
    
}


function goPython() {
    var script = document.createElement('script');


    script.src = 'https://code.jquery.com/jquery-3.3.1.js';
    script.type = 'text/javascript';
    script.integrity = 'sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=';
    script.crossOrigin = 'anonymous';
    document.getElementsByTagName('head')[0].appendChild(script);
    $.ajax({
        type: "POST",
        url: "test.py"
        // ,
        // data: { param: yourGlobalVariable}
    }).done(function () {
        // window.location = "index.php";
        alert('finished python script');;
    });
}
