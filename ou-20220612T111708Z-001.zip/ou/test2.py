from urllib.request import urlopen

urlopen.request.urlretrieve("http://www.python.org/images/success/nasa.jpg",
"NASA.jpg")

print("download successful")
print('Hello, world!')