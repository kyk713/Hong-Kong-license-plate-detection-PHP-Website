<?php

require __DIR__.'/vendor/autoload.php';

use Kreait\Firebase\Factory;

$factory = (new Factory)
    ->withServiceAccount('oufyp-8f2a7-firebase-adminsdk-sagqd-cc6aea8b3a.json')
    ->withDatabaseUri('https://oufyp-8f2a7-default-rtdb.firebaseio.com/');

    
$database = $factory->createDatabase();


?>