<?php
session_start();
include('includes/header.php');
?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php
            if (isset($_SESSION['status'])) {
                echo "<h5 class='alert alert-success'>" . $_SESSION['status'] . "</h5>";
                unset($_SESSION['status']);
            }
            ?>
            <div class="card">
                <div class="card-header">
                    <h4>PHP
                        <a href="add-contact.php" class="btn btn-primary float-end">ADD</a>
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>S1.no</th>
                                <th>Image</th>
                                <th>Result Image</th>
                                <th>Result OCR</th>
                                <th>Delete</th>

                            </tr>
                        </thead>
                        <tbody><?php
                                include('dbcon.php');
                                $ref_table = 'image';
                                $retchdata = $database->getReference($ref_table)->getValue();

                                if ($retchdata > 0) {

                                    $i = 0;
                                    foreach ($retchdata as $key => $row) {

                                ?>
                                    <tr>
                                        <td><?= $i++ ?></td>
                                        <td><img src="<?= $row['image'] ?>" alt="" style="width:200px; height:auto;">
                                        <td><?= $row['result'] ?></td>
                                        <td><?= $row['ocr'] ?></td>
                                        </td>
                                        <td>
                                            <a href="delete-contact.php" class="btn btn-primary btn-sm">delete</a>

                                        </td>
                                    </tr>

                                    
                                <?php
                                    }
                                } else {
                                ?>
                                <tr>
                                    <td colspan="7">No Record Found</td>
                                </tr>
                            <?php
                                }


                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php
    include('includes/footer.php');
    ?>